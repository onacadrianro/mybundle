<?php

return [
    '/' => ['controller' => 'IndexController', 'action' => 'indexAction'],
    '/summary' => ['controller' => 'OrderSummaryController', 'action' => 'indexAction'],
];
