<?php
//Best way is to set base url and credentials (if needed) in .env file. this requires to install "vlucas/phpdotenv"
return [
    'base_url' => 'http://mybundle.test/',
];
